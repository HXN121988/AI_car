#ifndef __AI_car_H
#define __AI_car_H


#include <ESP32Servo.h>
#include <HardwareSerial.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <HTTPClient.h>
#include <time.h>
#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include "driver/i2s.h"
// ==================== WiFi配置 自行修改 ====================
const char* WIFI_SSID     = "WIFI名称";
const char* WIFI_PWD      = "WIFI密码";
bool asrConfigFailed = false;
// ==================== 豆包ASR流式语音识别配置 ====================
const char* DOUBAO_ASR_API_KEY  = "语音模型的API_Key";
const char* ASR_RESOURCE_ID    = "volc.bigasr.sauc.duration";// 语音模型标识，豆包大模型 ASR 1.0 小时计费版
const char* ASR_HOST           = "openspeech.bytedance.com";// 语音服务器地址
const int   ASR_PORT           = 443;// HTTPS加密端口
const char* ASR_PATH           = "/api/v3/sauc/bigmodel_nostream";// 接口路径

// ==================== MPU6500姿态传感器配置 ====================
// I2C地址：AD0悬空=0x68，芯片ID=0x70
#define MPU6500_ADDR     0x68
// MPU6500寄存器定义（对应STM32的MPU6050_Reg.h）
#define MPU6500_SMPLRT_DIV    0x19
#define MPU6500_CONFIG        0x1A
#define MPU6500_GYRO_CONFIG   0x1B
#define MPU6500_ACCEL_CONFIG  0x1C
#define MPU6500_ACCEL_XOUT_H  0x3B
#define MPU6500_PWR_MGMT_1    0x6B
#define MPU6500_WHO_AM_I      0x75

// 传感器量程与灵敏度（和STM32平衡车2000°/s量程一致）
#define GYRO_RANGE_2000DPS    16.384f  // 2000°/s量程，灵敏度=32768/2000
#define ACCEL_RANGE_8G        4096.0f  // ±8G量程
#define CALI_SAMPLES 500               // 校准采样次数

// 在MPU6500配置区添加，1=正常方向，-1=反转方向
#define YAW_DIRECTION  1  

// 姿态解算参数
#define ATTITUDE_INTERVAL_MS  10       // 解算周期10ms，对应STM32定时器周期
float Yaw = 0.0f;                   // 航向角（核心：用于转弯角度控制）
float Pitch = 0.0f;                 // 俯仰角
float Roll = 0.0f;                  // 横滚角
float yawOffset = 0.0f;             // 航向角零点偏移
float gzOffset = 0.0f;              // Z轴陀螺仪零偏
uint32_t lastAttitudeTime = 0;

// 原始传感器数据（对应STM32的AX/AY/AZ/GX/GY/GZ）
int16_t ax, ay, az, gx, gy, gz;

// ----- 转向控制参数（可调，建议放在函数外作为全局常量） -----
const float SLOW_DEG     = 35.0f;   // 开始减速角度（度）
const float FINE_DEG     = 22.0f;    // 精细调节角度（度）
const float STOP_ADVANCE = 10.0f;    // 停止容忍误差（度）
const int   SPEED_MID    = 20;      // 中速值（PWM差量）
const int   SPEED_FINE   = 8;      // 慢速值（PWM差量）

// ==================== 超声波模块配置 ====================
#define TRIG_PIN        36    // Trig接GPIO36
#define ECHO_PIN        7     // Echo接GPIO7
#define SAFE_DISTANCE   5.0  // 安全停止距离，单位：厘米
#define ULTRA_INTERVAL  100    // 测距间隔，单位：毫秒
#define MAX_DISTANCE    99.0 // 最大测量范围，单位：厘米

float currentDistance = MAX_DISTANCE; // 当前测距值，初始为最大量程
uint32_t lastUltraTime = 0;    // 上次测距时间戳

// ASR状态显示控制
String asrStatus = "";       // 状态文本，空则不显示
uint32_t statusHoldEnd = 0;  // 临时状态保持截止时间

// ==================== INMP441麦克风硬件I2S ====================
#define I2S_MIC_PORT       I2S_NUM_0
#define I2S_MIC_BCLK       10
#define I2S_MIC_WS         11
#define I2S_MIC_SD         12
#define SAMPLE_RATE        16000
// ==================== 流式录音参数（解决长录音断开） ====================
#define AUDIO_CHUNK_BYTES 1024
#define MAX_RECORD_MS     8000
#define SILENCE_THRESHOLD 1200
#define SILENCE_END_MS    1000
int16_t audioChunkBuf[AUDIO_CHUNK_BYTES / 2];
uint32_t recordStartTime = 0;
uint32_t silenceStartTime = 0;
// 新增：音频滑动滤波，过滤舵机噪声
#define SILENCE_FILTER_NUM 5
int audioAvgBuf[SILENCE_FILTER_NUM] = {0};
uint8_t avgIdx = 0;
// ==================== WebSocket长连接保活 ====================
WebSocketsClient webSocket;
bool wsConnected = false;
uint32_t lastPingTime = 0;
#define WS_PING_INTERVAL 30000
String asrFinalResult = "";
bool asrResultReady = false;
// ==================== AI全局状态机（非阻塞核心） ====================
enum AiState {
  AI_IDLE,
  AI_RECORDING,
  AI_WAIT_RESULT,
  AI_PARSING_CMD,
  AI_EXECUTING
};
AiState aiState = AI_IDLE;
const byte WAKEUP_SIGNAL = 0xFF;
// ==================== 动作队列系统（实现正方形/圆弧复合动作） ====================
#define MAX_ACTION_QUEUE 20
typedef struct {
  uint8_t type;
  uint32_t duration;
} ActionItem;
// 动作定义：0停止 1前进 2后退 3差速左转 4差速右转 5原地左转 6原地右转 7跳舞
ActionItem actionQueue[MAX_ACTION_QUEUE];
uint8_t queueHead = 0;
uint8_t queueTail = 0;
ActionItem currentAction;
bool isActionRunning = false;
uint32_t actionStartMs = 0;
// ==================== OLED屏幕配置 ====================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET     -1
#define OLED_ADDR       0x3C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
const int ful_width   = 128;
const int full_height = 64;
// ==================== 舵机引脚定义 ====================
const int servoPinFrontLeft  = 2;
const int servoPinFrontRight = 14;
const int servoPinBackLeft   = 3;
const int servoPinBackRight  = 13;
Servo servoFL;
Servo servoFR;
Servo servoBL;
Servo servoBR;
// ==================== 串口硬件定义 ====================
const int uart1TxPin = 15;
const int uart1RxPin = 16;
const int uart2TxPin = 17;
const int uart2RxPin = 18;
const long uart1BaudRate = 9600;
const long uart2BaudRate = 115200;
HardwareSerial uart1(1);
HardwareSerial uart2(2);
// ==================== 蓝牙环形缓冲区 ====================
#define BLUE_SERIAL_BUFFER_SIZE   100
uint8_t BlueSerial_Buffer[BLUE_SERIAL_BUFFER_SIZE];
uint16_t BlueSerial_PutIndex = 0;
uint16_t BlueSerial_GetIndex = 0;
char BlueSerial_String[100];
char BlueSerial_StringArray[6][20];
// ==================== 360舵机速度参数 ====================
const int STOP_SPEED    = 95;
const int LEFT_FORWARD  = 85;
const int LEFT_BACK     = 105;
const int RIGHT_FORWARD = 105;
const int RIGHT_BACK    = 85;


//===================== 小车运动标定参数（实测校准，不要修改）====
#define STRAIGHT_MS_PER_CM    135.63f   // 每厘米直行毫秒
#define TURN_MS_PER_DEGREE    24.95f   // 每度原地右转毫秒

// ==================== 摇杆死区 =========================
const int JOYSTICK_DEAD_ZONE = 10;
// ==================== 基础单指令编码 ====================
const char forwardCmd   = 1;
const char backwardCmd  = 2;
const char leftCmd      = 3;
const char rightCmd     = 4;
const char stopCmd      = 0;
const char sitDownCmd   = 5;
const char lieDownCmd   = 6;
const char danceCmd     = 7;

// ==================== GPIO8按键与控制模式切换 ====================
#define KEY_PIN 8
#define KEY_DEBOUNCE_MS 20
uint32_t lastKeyTick = 0;
uint8_t lastKeyState = HIGH;
enum CtrlMode {
  MODE_FIX_ASR,    // 固定语音控制（离线语音模块）
  MODE_LLM_ASR,    // AI大模型自然语音控制
  MODE_BLUETOOTH   // 外部蓝牙模块控制
};
CtrlMode ctrlMode = MODE_FIX_ASR; // 默认启动为固定语音模式




// ==================== 函数声明 ====================
// 运动控制
void moveForward();
void moveBackward();
void turnLeft();
void turnRight();
void stopMovement();
void sitDown();
void lieDown();
void dance();
void setMotorSpeed(int leftSpeed, int rightSpeed);
void controlByJoystick(int8_t LV, int8_t RH);
void processCommand(char command);
// 蓝牙环形串口
uint8_t BlueSerial_Put(uint8_t Byte);
uint8_t BlueSerial_Get(uint8_t *Byte);
uint16_t BlueSerial_Length(void);
uint8_t BlueSerial_Read(uint16_t Index);
void BlueSerial_ClearBuffer(void);
void BlueSerial_SendString(char *String);
void BlueSerial_Printf(const char *format, ...);
uint8_t BlueSerial_ReceiveFlag(void);
void BlueSerial_Receive(void);
// WiFi & 麦克风
void connectWiFi();
void initMicrophone();

// ASR语音识别
String generateUUID();
void buildPacket(uint8_t* outBuf, int &outLen, uint8_t msgType, bool isLast, const uint8_t* payload, int payloadLen);
void asrWebSocketEvent(WStype_t type, uint8_t * payload, size_t length);
void maintainASRConnection();
void startStreamASR();
void processRecording();
// LLM动作解析
void parseLLMToActions(String text);
// 动作队列管理
bool enqueueAction(ActionItem act);
void clearActionQueue();
void runAction(uint8_t type);
void processActionQueue();
// AI总调度
void processAI();
// OLED状态显示
void showStatus(String txt);
void updateOLED();
//超声波函数
float getDistance();
void checkObstacle();
// 【新增】按键与模式切换函数
void initKey();
void handleKeySwitch();
void switchControlMode(CtrlMode newMode);
//MPU6500底层驱动函数
void mpu6500WriteReg(uint8_t reg, uint8_t val);
void mpu6500ReadRegs(uint8_t reg, uint8_t len, uint8_t *buf);
bool mpu6500Init();
void mpu6500GetRawData();
void mpu6500CalibrateGyro();
void resetYaw();
// 姿态解算（互补滤波）
void updateAttitude();

#endif




#include <AI_car.h>


// ==================== MPU6500底层驱动函数 ====================
// 写单寄存器（对应STM32的MPU6050_WriteReg）
void mpu6500WriteReg(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU6500_ADDR);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

// 连续读多寄存器（对应STM32的MPU6050_ReadRegs）
void mpu6500ReadRegs(uint8_t reg, uint8_t len, uint8_t *buf) {
  Wire.beginTransmission(MPU6500_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU6500_ADDR, len);
  for (uint8_t i = 0; i < len; i++) {
    buf[i] = Wire.read();
  }
}

// MPU6500初始化（对应STM32的MPU6050_Init）
bool mpu6500Init() {
  // 读取芯片ID，验证是MPU6500
  uint8_t chipID;
  mpu6500ReadRegs(MPU6500_WHO_AM_I, 1, &chipID);
  if (chipID != 0x70) {
    Serial.print("[MPU] 芯片ID错误:0x");
    Serial.println(chipID, HEX);
    return false;
  }
  
  // 电源管理：唤醒芯片，PLL参考时钟
  mpu6500WriteReg(MPU6500_PWR_MGMT_1, 0x01);
  // 采样分频：1kHz/(1+7)=125Hz
  mpu6500WriteReg(MPU6500_SMPLRT_DIV, 0x07);
  // 配置低通滤波：21Hz，降噪
  mpu6500WriteReg(MPU6500_CONFIG, 0x03);
  // 陀螺仪量程：±2000°/s
  mpu6500WriteReg(MPU6500_GYRO_CONFIG, 0x18);
  // 加速度计量程：±8G
  mpu6500WriteReg(MPU6500_ACCEL_CONFIG, 0x10);
  
  Serial.println("[MPU] MPU6500初始化成功，ID=0x70");
  return true;
}

// 读取全部原始数据（对应STM32的MPU6050_GetData）
void mpu6500GetRawData() {
  uint8_t buf[14];
  mpu6500ReadRegs(MPU6500_ACCEL_XOUT_H, 14, buf);
  ax = (buf[0] << 8) | buf[1];
  ay = (buf[2] << 8) | buf[3];
  az = (buf[4] << 8) | buf[5];
  gx = (buf[8] << 8) | buf[9];
  gy = (buf[10] << 8) | buf[11];
  gz = (buf[12] << 8) | buf[13];
}

// 航向角归零校准
void resetYaw() {
  Yaw = 0.0f;
}

// 陀螺仪零偏校准：上电后静止执行，消除零点漂移
void mpu6500CalibrateGyro() {
  Serial.println("[MPU] 开始陀螺仪校准，请保持小车静止...");
  int32_t sum = 0;
  
  for (int i = 0; i < CALI_SAMPLES; i++) {
    mpu6500GetRawData();
    sum += gz;
    delay(2);
  }
  
  gzOffset = (float)sum / CALI_SAMPLES;
  Serial.print("[MPU] 校准完成，Z轴零偏: ");
  Serial.println(gzOffset, 2);
}

// ==================== 姿态解算（互补滤波） ====================
// 对应STM32定时器中断里的角度计算逻辑，非阻塞定时调用
void updateAttitude() {
  if (millis() - lastAttitudeTime < ATTITUDE_INTERVAL_MS) {
    return;
  }
  lastAttitudeTime = millis();
  
  mpu6500GetRawData();
  
  // 减去零偏，再转换为物理单位
  float gz_dps = (gz - gzOffset) / GYRO_RANGE_2000DPS;  
  float ax_g = ax / ACCEL_RANGE_8G;
  float ay_g = ay / ACCEL_RANGE_8G;
  float az_g = az / ACCEL_RANGE_8G;
  
  float deltaT = ATTITUDE_INTERVAL_MS / 1000.0f;
  Yaw += gz_dps * deltaT * YAW_DIRECTION;
  
  // 俯仰横滚互补滤波（保持不变）
  float accPitch = atan2(-ay_g, az_g) * 180.0f / PI;
  float accRoll  = atan2(ax_g, sqrt(ay_g*ay_g + az_g*az_g)) * 180.0f / PI;
  
  float alpha = 0.02;
  Pitch = alpha * accPitch + (1 - alpha) * Pitch;
  Roll  = alpha * accRoll  + (1 - alpha) * Roll;
}



//=================获取前方距离，单位：厘米；超时返回100.0表示无障碍物==================

float getDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  
  // 100cm对应往返时间约5882微秒，设置6000微秒超时
  long duration = pulseIn(ECHO_PIN, HIGH, 6000);
  if (duration == 0) {
    return MAX_DISTANCE; // 无障碍物/超量程，返回最大值
  }
  
  float dist = duration * 0.034 / 2.0;
  // 强制限制在0-100cm范围内
  dist = constrain(dist, 0.0f, MAX_DISTANCE);
  return dist;
}

//=========================障碍物检测与紧急停止（全模式生效）================================
void checkObstacle() {
  // 按间隔测距，避免频繁调用占用资源
  if (millis() - lastUltraTime < ULTRA_INTERVAL) {
    return;
  }
  lastUltraTime = millis();
  currentDistance = getDistance();

  // 距离小于安全值且有效，执行紧急停止
  if (currentDistance < SAFE_DISTANCE && currentDistance > 0) {
    // 停止电机 + 清空动作队列 + 重置AI状态
    stopMovement();
    clearActionQueue();
    aiState = AI_IDLE;

    // 若正在进行语音识别，强制断开连接
    if (wsConnected) {
      webSocket.disconnect();
      wsConnected = false;
      for(int i=0;i<100;i++) webSocket.loop();
    }

    // 清空蓝牙缓冲区，避免旧指令继续执行
    BlueSerial_ClearBuffer();
    while (uart1.available()) uart1.read();

    Serial.print("[避障] 障碍物距离: ");
    Serial.print(currentDistance, 1);
    Serial.println("cm，已紧急停止");
    
  }
  // 每次测距后刷新OLED，保证距离数值实时更新
  updateOLED();
}

// ==================== 【新增】统一OLED刷新（模式+速度） ====================
void updateOLED() {
  // 空闲状态下，自动清除超时的临时提示
  if (aiState == AI_IDLE && asrStatus.length() > 0 && millis() > statusHoldEnd) {
    asrStatus = "";
  }

  String modeStr;
  switch(ctrlMode) {
    case MODE_FIX_ASR:   modeStr = "Fix Voice";   break;
    case MODE_LLM_ASR:   modeStr = "AI Voice";    break;
    case MODE_BLUETOOTH: modeStr = "Bluetooth";   break;
  }
  
  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(SSD1306_WHITE);
  
  // 第1行：控制模式
  display.setCursor(0, 0);
  display.println(modeStr);
  
  // 第2行：实时距离（全程常显）
  display.setCursor(0, 24);
  display.print("DST:");
  display.print(currentDistance, 1);
  display.print("cm");
  
  // 第3行：ASR识别状态（有内容才显示）
  if (asrStatus.length() > 0) {
    display.setCursor(0, 48);
    display.println(asrStatus);
  }
  
  display.display();
}


//======================== OLED临时状态提示（如“识别中”“连接中”）========================
void showStatus(String txt){
  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0,16);
  display.println(txt);
  display.display();
}
//============================== WIFI连接 ============================================
void connectWiFi() {
  Serial.print("连接WiFi: ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PWD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi连接成功");
}

//=============================== 初始化INMP441麦克风 =============================================
void initMicrophone() {
  i2s_config_t i2sConfig = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk = 0
  };
  i2s_driver_install(I2S_MIC_PORT, &i2sConfig, 0, NULL);
  i2s_pin_config_t pinConfig = {
    .bck_io_num = I2S_MIC_BCLK,
    .ws_io_num = I2S_MIC_WS,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = I2S_MIC_SD
  };
  i2s_set_pin(I2S_MIC_PORT, &pinConfig);
  Serial.println("INMP441 麦克风初始化完成");
}

//============================ 生成简易UUID（用于请求ID）=================================
String generateUUID() {
  String uuid = "";
  for (int i = 0; i < 32; i++) {
    int r = random(0, 16);
    uuid += String(r, HEX);
    if (i == 7 || i == 11 || i == 15 || i == 19) uuid += "-";
  }
  return uuid;
}

//======================= 封装二进制消息包（匹配官方协议：4字节Header + 4字节大端长度 + Payload）==================
void buildPacket(uint8_t* outBuf, int &outLen, uint8_t msgType, bool isLast, const uint8_t* payload, int payloadLen) {
  outBuf[0] = 0x11;
  outBuf[1] = (msgType << 4);
  if (isLast) outBuf[1] |= 0x02;
  if (msgType == 0x01) {
    outBuf[2] = 0x10;
  } else {
    outBuf[2] = 0x00;
  }
  outBuf[3] = 0x00;
  outBuf[4] = (payloadLen >> 24) & 0xFF;
  outBuf[5] = (payloadLen >> 16) & 0xFF;
  outBuf[6] = (payloadLen >> 8) & 0xFF;
  outBuf[7] = payloadLen & 0xFF;
  if (payload != nullptr && payloadLen > 0) {
    memcpy(outBuf + 8, payload, payloadLen);
  }
  outLen = 8 + payloadLen;
}

//============================== WebSocket事件回调 ===========================================
void asrWebSocketEvent(WStype_t type, uint8_t * payload, size_t length) {
  switch(type) {
    case WStype_CONNECTED:
      wsConnected = true;
      Serial.println("[ASR] WebSocket长连接建立成功");
      break;
    case WStype_BIN: {
      uint8_t msgType = (payload[1] >> 4) & 0x0F;
      Serial.printf("[ASR] 收到二进制消息，类型:0x%02X，长度:%d\n", msgType, length);
      if (msgType == 0x0F && length >= 12) {
        asrConfigFailed = true;
        uint32_t errorCode = ((uint32_t)payload[4] << 24) | ((uint32_t)payload[5] << 16) | ((uint32_t)payload[6] << 8) | payload[7];
        Serial.printf("[ASR] 服务端错误码: %08X\n", errorCode);
      }
      if (msgType == 0x09 && length > 12) {
        int jsonLen = length - 12;
        char* jsonStr = (char*)malloc(jsonLen + 1);
        memcpy(jsonStr, payload + 12, jsonLen);
        jsonStr[jsonLen] = '\0';
        Serial.printf("[ASR] 结果JSON: %s\n", jsonStr);
        
        DynamicJsonDocument doc(2048);
        if (deserializeJson(doc, jsonStr) == DeserializationError::Ok) {
          if (doc.containsKey("result") && doc["result"].containsKey("text")) {
            String text = doc["result"]["text"].as<String>();
            if (text.length() > 0) {
              asrFinalResult = text;
              asrResultReady = true;
              asrStatus = "Rec OK";
              statusHoldEnd = millis() + 2000; // 识别成功保持2秒
              Serial.print("[ASR] 识别结果: ");
              Serial.println(asrFinalResult);
            }
          }
        }
        free(jsonStr);
      }
      break;
    }
    case WStype_DISCONNECTED:
    case WStype_ERROR:
      wsConnected = false;
      Serial.println("[ASR] 连接断开");
    default: break;
  }
}

//================================= 启动流式语音识别 ===================================
void startStreamASR() {
  if (wsConnected) {
    webSocket.disconnect();
    wsConnected = false;
    for (int i = 0; i < 20; i++) { webSocket.loop(); delay(10); }
  }
  asrFinalResult = "";
  asrResultReady = false;
  asrConfigFailed = false;
  recordStartTime = millis();
  silenceStartTime = 0;

  String requestId = generateUUID();
  String connectId = generateUUID();
  String headers = 
    "X-Api-Key: " + String(DOUBAO_ASR_API_KEY) + "\r\n"
    "X-Api-Resource-Id: " + String(ASR_RESOURCE_ID) + "\r\n"
    "X-Api-Request-Id: " + requestId + "\r\n"
    "X-Api-Connect-Id: " + connectId + "\r\n"
    "X-Api-Sequence: -1";
  
  webSocket.onEvent(asrWebSocketEvent);
  webSocket.beginSSL(ASR_HOST, ASR_PORT, ASR_PATH);
  webSocket.setExtraHeaders(headers.c_str());

  int timeout = 0;
  while (!wsConnected && timeout < 40) {
    webSocket.loop();
    delay(50);
    timeout++;
  }
  
  if (!wsConnected) {
    Serial.println("[ASR] 连接失败，取消识别");
    aiState = AI_IDLE;
    // 新增：连接失败提示，保持2秒
    asrStatus = "Connect Fail";
    statusHoldEnd = millis() + 2000;
    return;
  }

  String configJson =
  "{\"audio\":{\"format\":\"pcm\",\"rate\":16000,\"bits\":16,\"channel\":1},"
  "\"request\":{\"model_name\":\"bigmodel\",\"enable_punc\":false,\"enable_itn\":false}}";
    uint8_t pktBuf[512];
    int pktLen;
    buildPacket(pktBuf, pktLen, 0x01, false, (uint8_t*)configJson.c_str(), configJson.length());
    webSocket.sendBIN(pktBuf, pktLen);

    uint32_t waitConfigTick = millis();
    bool configOk = false;
    while(millis() - waitConfigTick < 2000){
      webSocket.loop();
      if(asrConfigFailed){
        Serial.println("[ASR] 配置包服务端返回错误，终止识别");
        webSocket.disconnect();
        wsConnected = false;
        aiState = AI_IDLE;
        // 新增：配置失败提示
        asrStatus = "Config Fail";
        statusHoldEnd = millis() + 2000;
        return;
      }
      delay(30);
      configOk = true;
    }
    if(!configOk){
      Serial.println("[ASR] 等待配置回执超时");
      webSocket.disconnect();
      wsConnected = false;
      aiState = AI_IDLE;
      return;
    }
    aiState = AI_RECORDING;
    Serial.println("[ASR] 连接&配置完成，开始流式录音");
    asrStatus = "Speak now"; // 录音阶段一直显示，直到录音结束
}

//============================== 分片读取麦克风并发送音频（非阻塞）================================
void processRecording() {
  size_t bytesRead = 0;
  i2s_read(I2S_MIC_PORT, audioChunkBuf, AUDIO_CHUNK_BYTES, &bytesRead, pdMS_TO_TICKS(10));
  if (bytesRead == 0) return;
  int32_t sum = 0;
  for (int i = 0; i < bytesRead / 2; i++) sum += abs(audioChunkBuf[i]);
  int avg = sum / (bytesRead / 2);

  audioAvgBuf[avgIdx] = avg;
  avgIdx = (avgIdx + 1) % SILENCE_FILTER_NUM;
  int smoothAvg = 0;
  for(uint8_t i=0;i<SILENCE_FILTER_NUM;i++){
    smoothAvg += audioAvgBuf[i];
  }
  smoothAvg /= SILENCE_FILTER_NUM;

  bool isLast = false;
  if (smoothAvg < SILENCE_THRESHOLD) {
    if (silenceStartTime == 0) silenceStartTime = millis();
    else if (millis() - silenceStartTime > SILENCE_END_MS) {
      isLast = true;
      Serial.println("[ASR] 检测静音，结束录音");
    }
  }
  else silenceStartTime = 0;

  if (millis() - recordStartTime > MAX_RECORD_MS) {
    isLast = true;
    Serial.println("[ASR] 到达最大录音时长，结束录音");
  }

  uint8_t sendBuf[AUDIO_CHUNK_BYTES + 8];
  int pktLen;
  buildPacket(sendBuf, pktLen, 0x02, isLast, (uint8_t*)audioChunkBuf, bytesRead);
  webSocket.sendBIN(sendBuf, pktLen);
  webSocket.loop();
  if (isLast) aiState = AI_WAIT_RESULT;
}

//============================= LLM自然语言转动作队列 ========================================
void parseLLMToActions(String text) {
  int retryCnt = 0;
  const int MAX_RETRY = 2;
  int httpCode = -1;
  String payloadStr = "";
  while(retryCnt <= MAX_RETRY){
    HTTPClient http;
    http.setTimeout(10000);
    http.begin("https://ark.cn-beijing.volces.com/api/v3/chat/completions");
    http.addHeader("Content-Type", "application/json");
    http.addHeader("Authorization", "Bearer 推理模型的API_Key");
    DynamicJsonDocument reqDoc(512);
    reqDoc["model"] = "推理模型接入点ID";
    reqDoc["temperature"] = 0;
    reqDoc["max_tokens"] = 600;
    JsonArray messages = reqDoc.createNestedArray("messages");
    JsonObject msg = messages.createNestedObject();
    msg["role"] = "user";
    msg["content"] =  "仅输出一行纯JSON数组，无任何多余文字、空格、换行、解释！"
                    "动作编码严格遵守：5=原地左转，6=原地右转，绝对不能搞反左右！"
                    "单位规则："
                    "1. 前进(action=1)、后退(action=2)：duration单位为毫秒，1厘米=112.5毫秒；"
                    "2. 原地左转(action=5)、原地右转(action=6)：duration单位为角度(度)，直接填目标角度数值；"
                    "支持指令类型："
                    "- 距离角度：前进X厘米、后退X厘米、左转X度、右转X度；"
                    "- 几何图形：正方形每段直行后右转90度；等边三角形右转120度；正五边形右转72度；"
                    "- 复合动作：支持多段直行+转向拼接；"
                    "严格参考样例格式："
                    "样例1 右转90度再前进20厘米：[{\"action\":6,\"duration\":90},{\"action\":1,\"duration\":2250}]"
                    "样例2 左转45度后退10厘米：[{\"action\":5,\"duration\":45},{\"action\":2,\"duration\":1125}]"
                    "样例3 边长30厘米正方形：[{\"action\":1,\"duration\":3375},{\"action\":6,\"duration\":90},{\"action\":1,\"duration\":3375},{\"action\":6,\"duration\":90},{\"action\":1,\"duration\":3375},{\"action\":6,\"duration\":90},{\"action\":1,\"duration\":3375}]"
                    "用户指令：" + text;
    String body;
    serializeJson(reqDoc, body);
    httpCode = http.POST(body);
    payloadStr = http.getString();
    http.end();
    delay(300);
    if(httpCode == 200){
      break;
    }
    else{
      retryCnt++;
      Serial.printf("[LLM] 请求失败 code:%d 重试%d/%d\n", httpCode, retryCnt, MAX_RETRY);
    }
  }
  if (httpCode == 200) {
    DynamicJsonDocument doc(1024);
    deserializeJson(doc, payloadStr);
    String content = doc["choices"][0]["message"]["content"].as<String>();
    content.trim();
    Serial.println("[LLM] 原始返回内容:");
    Serial.println(content);   // 打印原始 JSON 字符串

    DynamicJsonDocument actDoc(1024);
    if (deserializeJson(actDoc, content) == DeserializationError::Ok) {
      clearActionQueue();
      JsonArray arr = actDoc.as<JsonArray>();
      Serial.println("[LLM] 解析动作序列：");
      for (JsonObject item : arr) {
        ActionItem act;
        act.type = item["action"].as<uint8_t>();
        act.duration = item["duration"].as<uint32_t>();
        Serial.print("  action=");
        Serial.print(act.type);
        Serial.print("  duration=");
        Serial.println(act.duration);
        enqueueAction(act);
      }
      aiState = AI_EXECUTING;
      Serial.println("[LLM] 复合动作序列加载完成");
    } 
    else {
      Serial.print("[LLM] JSON解析失败，返回内容：");
      Serial.println(content);
      aiState = AI_IDLE;
    }
  } 
  else {
    Serial.print("[LLM] 最终请求失败，错误码：");
    Serial.println(httpCode);
    Serial.print("[LLM] 错误详情：");
    Serial.println(payloadStr);
    aiState = AI_IDLE;
  }
}

//=============================== 动作队列基础操作 =========================================
bool enqueueAction(ActionItem act) {
  uint8_t next = (queueTail + 1) % MAX_ACTION_QUEUE;
  if (next == queueHead) return false;
  actionQueue[queueTail] = act;
  queueTail = next;
  return true;
}

void clearActionQueue() {
  Serial.println("[DEBUG] *** clearActionQueue() 被调用！***");
  queueHead = 0;
  queueTail = 0;
  isActionRunning = false;
  stopMovement();
}

void runAction(uint8_t type) {
  switch(type) {
    case 1: moveForward(); break;
    case 2: moveBackward(); break;
    case 3: turnLeft(); break;
    case 4: turnRight(); break;
    case 5: // 原地左转，与固定语音左转方向一致
      servoFL.write(LEFT_FORWARD); servoBL.write(LEFT_FORWARD);
      servoFR.write(RIGHT_BACK); servoBR.write(RIGHT_BACK);
      break;
    case 6: // 原地右转，与固定语音右转方向一致
      servoFL.write(LEFT_BACK); servoBL.write(LEFT_BACK);
      servoFR.write(RIGHT_FORWARD); servoBR.write(RIGHT_FORWARD);
      break;
    case 7: dance(); break;
    default: stopMovement(); break;
  }
}

//================================= 非阻塞执行动作队列 ========================================
void processActionQueue() {
    if (!isActionRunning) {
        if (queueHead != queueTail) {
            currentAction = actionQueue[queueHead];
            queueHead = (queueHead + 1) % MAX_ACTION_QUEUE;
            isActionRunning = true;
            actionStartMs = millis();
            if (currentAction.type == 5 || currentAction.type == 6) {
                resetYaw();
                // 记录转向开始时间用于超时
                actionStartMs = millis();  // 复用这个变量
                Serial.printf("[动作队列] 执行转向 type=%d 目标=%d度\n", currentAction.type, currentAction.duration);
            }
            runAction(currentAction.type);
        }
    } else {
        bool actionFinish = false;
        float targetAngle = (float)currentAction.duration;

        if (currentAction.type == 5 || currentAction.type == 6) {
            // 方向判断：根据您的 YAW_DIRECTION=1，右转目标为负，左转为正
            float targetYaw = (currentAction.type == 5) ? targetAngle : -targetAngle;
            float remain = targetYaw - Yaw;

            // 超时保护：期望时间（角度*每度时间）的 1.5 倍
            uint32_t expectedMs = (uint32_t)(targetAngle * TURN_MS_PER_DEGREE * 1.5);
            if (millis() - actionStartMs > expectedMs) {
                Serial.printf("[动作队列] 转向超时，强制完成 (Yaw=%.2f)\n", Yaw);
                actionFinish = true;
            }
            else if (fabs(remain) <= STOP_ADVANCE) {
                actionFinish = true;
                Serial.printf("[动作队列] 转向完成 实际Yaw=%.2f\n", Yaw);
            } else {
                int speed;
                if (fabs(remain) < FINE_DEG)       speed = SPEED_FINE;
                else if (fabs(remain) < SLOW_DEG)  speed = SPEED_MID;
                else                               speed = 50;

                if (remain > 0) {
                    setMotorSpeed(speed, -speed);   // 左转
                } else {
                    setMotorSpeed(-speed, speed);   // 右转
                }
                // 可选：打印调试信息
                // Serial.printf("[转向] Yaw=%.2f target=%.2f remain=%.2f speed=%d\n", Yaw, targetYaw, remain, speed);
            }
        } else {
            // 直行/后退时间控制
            if (millis() - actionStartMs >= currentAction.duration) {
                actionFinish = true;
            }
        }

        if (actionFinish) {
            isActionRunning = false;
            stopMovement();
        }
    }
}
//================================ AI状态机总调度 ========================================
void processAI() {
  if (aiState == AI_RECORDING || aiState == AI_WAIT_RESULT) {
    webSocket.loop();
  }
  switch(aiState) {
    case AI_IDLE: break;
    case AI_RECORDING:
      if (wsConnected) processRecording();
      break;
    case AI_WAIT_RESULT: {
      static uint32_t waitStart = 0;
      if (asrResultReady) {
        waitStart = 0;
        if (wsConnected) {
          webSocket.disconnect();
          wsConnected = false;
          for(int i=0;i<100;i++){
            webSocket.loop();
            delay(20);
          }
        }
        delay(800);
        aiState = AI_PARSING_CMD;
      } 
      else if (waitStart == 0) {
        waitStart = millis();
      } 
      else if (millis() - waitStart > 8000) {
        waitStart = 0;
        if (wsConnected) {
          webSocket.disconnect();
          wsConnected = false;
          for(int i=0;i<100;i++) webSocket.loop();
        }
        aiState = AI_IDLE;
        Serial.println("[ASR] 识别超时，未收到结果");
        asrStatus = "Retry please";
        statusHoldEnd = millis() + 2000; // 失败提示保持2秒
      }
      break;
    }
    case AI_PARSING_CMD:
      parseLLMToActions(asrFinalResult);
      break;
    case AI_EXECUTING:
      if (queueHead == queueTail && !isActionRunning) {
        aiState = AI_IDLE;
        Serial.println("[AI] 全部动作执行完毕，回到空闲");
      }
      break;
  }
}

// ==================== 按键初始化 ====================
void initKey() {
  pinMode(KEY_PIN, INPUT_PULLUP);
  lastKeyState = digitalRead(KEY_PIN);
  Serial.println("GPIO8按键初始化完成，默认固定语音模式");
}

// ==================== 按键检测与模式切换触发 ====================
void handleKeySwitch() {
    static uint32_t lastValidPressTime = 0;
    static bool lastStableState = HIGH;
    static uint32_t debounceStart = 0;
    static bool debounceActive = false;
    
    uint32_t now = millis();
    
    // 冷却期：切换后 2000ms 内不处理
    if (now - lastValidPressTime < 2000) return;
    
    uint8_t currentState = digitalRead(KEY_PIN);
    
    // 检测到电平变化时开始消抖计时
    if (currentState != lastStableState) {
        if (!debounceActive) {
            debounceActive = true;
            debounceStart = now;
        }
    } else {
        // 电平恢复稳定，重置消抖状态
        debounceActive = false;
    }
    
    // 如果处于消抖等待中，且稳定时间超过 50ms
    if (debounceActive && (now - debounceStart > 50)) {
        // 现在电平稳定为 currentState
        if (currentState == LOW) {  // 确认按下（低电平有效）
            // 执行切换
            CtrlMode nextMode;
            switch(ctrlMode) {
                case MODE_FIX_ASR:   nextMode = MODE_LLM_ASR; break;
                case MODE_LLM_ASR:   nextMode = MODE_BLUETOOTH; break;
                case MODE_BLUETOOTH: nextMode = MODE_FIX_ASR; break;
            }
            switchControlMode(nextMode);
            lastValidPressTime = now;   // 记录切换时间，进入冷却
        }
        // 无论是否切换，重置消抖状态
        debounceActive = false;
        lastStableState = currentState;
    }
}

// ==================== 执行模式切换+状态清理 ====================
void switchControlMode(CtrlMode newMode) {
  // 通用清理：停止电机、清空动作队列、重置AI状态
  clearActionQueue();
  stopMovement();
  aiState = AI_IDLE;
  
  // 断开ASR WebSocket连接，释放资源
  if (wsConnected) {
    webSocket.disconnect();
    wsConnected = false;
    for(int i=0;i<100;i++) webSocket.loop();
  }
  
  // 清空蓝牙缓冲区，避免旧数据干扰
  BlueSerial_ClearBuffer();
  while (uart1.available()) uart1.read();
  
  // 更新当前模式
  ctrlMode = newMode;
  
  // 串口打印 + OLED显示当前模式
  String modeName;
  switch(ctrlMode) {
    case MODE_FIX_ASR:
      modeName = "固定语音模式";
      break;
    case MODE_LLM_ASR:
      modeName = "AI大模型模式";
      break;
    case MODE_BLUETOOTH:
      modeName = "蓝牙控制模式";
      break;
  }
  Serial.print("切换控制模式：");
  Serial.println(modeName);
  updateOLED();
  delay(500); // 模式提示停留，避免快速连按
}

// ==================== 蓝牙串口核心函数 ====================
uint8_t BlueSerial_Put(uint8_t Byte) {
  if ((BlueSerial_PutIndex + 1) % BLUE_SERIAL_BUFFER_SIZE == BlueSerial_GetIndex) {
    return 1;
  }
  BlueSerial_Buffer[BlueSerial_PutIndex] = Byte;
  if (BlueSerial_PutIndex >= BLUE_SERIAL_BUFFER_SIZE - 1) {
    BlueSerial_PutIndex = 0;
  } else {
    BlueSerial_PutIndex ++;
  }
  return 0;
}

uint8_t BlueSerial_Get(uint8_t *Byte) {
  if (BlueSerial_GetIndex == BlueSerial_PutIndex) {
    *Byte = 0;
    return 1;
  }
  *Byte = BlueSerial_Buffer[BlueSerial_GetIndex];
  if (BlueSerial_GetIndex >= BLUE_SERIAL_BUFFER_SIZE - 1) {
    BlueSerial_GetIndex = 0;
  } else {
    BlueSerial_GetIndex ++;
  }
  return 0;
}

uint16_t BlueSerial_Length(void) {
  return (BlueSerial_PutIndex + BLUE_SERIAL_BUFFER_SIZE - BlueSerial_GetIndex) % BLUE_SERIAL_BUFFER_SIZE;
}

uint8_t BlueSerial_Read(uint16_t Index) {
  return BlueSerial_Buffer[(BlueSerial_GetIndex + Index) % BLUE_SERIAL_BUFFER_SIZE];
}

void BlueSerial_ClearBuffer(void) {
  uint16_t i;
  for (i = 0; i < BLUE_SERIAL_BUFFER_SIZE; i ++) {
    BlueSerial_Buffer[i] = 0;
  }
  BlueSerial_PutIndex = 0;
  BlueSerial_GetIndex = 0;
}

void BlueSerial_SendString(char *String) {
  uint8_t i;
  for (i = 0; String[i] != '\0'; i ++) {
    uart1.write(String[i]);
  }
}

void BlueSerial_Printf(const char *format, ...) {
  char String[100];
  va_list arg;
  va_start(arg, format);
  vsprintf(String, format, arg);
  va_end(arg);
  BlueSerial_SendString(String);
}

// 检测是否收到完整的 [] 数据包
uint8_t BlueSerial_ReceiveFlag(void) {
  uint8_t Flag = 0;
  uint16_t Length = BlueSerial_Length();
  for (uint16_t i = 0; i < Length; i ++) {
    if (BlueSerial_Read(i) == '[') {
      Flag = 1;
    }
    else if (BlueSerial_Read(i) == ']' && Flag == 1) {
      return 1;
    }
  }
  return 0;
}

//====================== 提取数据包并按逗号分割 ==================================
void BlueSerial_Receive(void) {
  uint16_t p = 0, k = 0;
  uint8_t Flag = 0;
  uint16_t Length = BlueSerial_Length();
  for (uint16_t i = 0; i < Length; i ++) {
    uint8_t Byte;
    BlueSerial_Get(&Byte);
    if (Byte == '[') {
      Flag = 1;
      p = 0;
    }
    else if (Byte == ']' && Flag == 1) {
      BlueSerial_String[p] = '\0';
      break;
    }
    else if (Flag == 1) {
      BlueSerial_String[p] = Byte;
      p ++;
    }
  }
  p = 0; k = 0;
  for (uint16_t i = 0; BlueSerial_String[i] != '\0'; i ++) {
    if (BlueSerial_String[i] == ',') {
      BlueSerial_StringArray[p][k] = '\0';
      p ++;
      k = 0;
    }
    else {
      BlueSerial_StringArray[p][k] = BlueSerial_String[i];
      k ++;
    }
  }
  BlueSerial_StringArray[p][k] = '\0';
}

//============================= 摇杆控制逻辑 ===================================
void controlByJoystick(int8_t LV, int8_t RH) {
  if (abs(LV) < JOYSTICK_DEAD_ZONE) LV = 0;
  if (abs(RH) < JOYSTICK_DEAD_ZONE) RH = 0;
  if (LV == 0 && RH == 0) {
    stopMovement();
    return;
  }
  int leftSpeed = LV - RH;
  int rightSpeed = LV + RH;
  leftSpeed = constrain(leftSpeed, -100, 100);
  rightSpeed = constrain(rightSpeed, -100, 100);
  setMotorSpeed(leftSpeed, rightSpeed);
  
}

//=========================== 舵机速度映射函数 ================================
void setMotorSpeed(int leftSpeed, int rightSpeed) {
  int leftPulse, rightPulse;
  if (leftSpeed >= 0) {
    leftPulse = map(leftSpeed, 0, 100, STOP_SPEED, LEFT_FORWARD);
  } else {
    leftPulse = map(-leftSpeed, 0, 100, STOP_SPEED, LEFT_BACK);
  }
  if (rightSpeed >= 0) {
    rightPulse = map(rightSpeed, 0, 100, STOP_SPEED, RIGHT_FORWARD);
  } else {
    rightPulse = map(-rightSpeed, 0, 100, STOP_SPEED, RIGHT_BACK);
  }
  leftPulse = constrain(leftPulse, min(LEFT_FORWARD, RIGHT_BACK), max(LEFT_BACK, RIGHT_FORWARD));
  rightPulse = constrain(rightPulse, min(LEFT_FORWARD, RIGHT_BACK), max(LEFT_BACK, RIGHT_FORWARD));
  servoFL.write(leftPulse);
  servoBL.write(leftPulse);
  servoFR.write(rightPulse);
  
  servoBR.write(rightPulse);
}

//================================ 运动控制函数 ==============================
void moveForward() {
  Serial.println("前进");
  uart1.println("前进");
  updateOLED(); // 替换原来的三行表情代码

  servoFL.write(LEFT_FORWARD);
  servoBL.write(LEFT_FORWARD);
  servoFR.write(RIGHT_FORWARD);
  servoBR.write(RIGHT_FORWARD);
}

void moveBackward() {
  Serial.println("后退");
  uart1.println("后退");
  updateOLED(); // 替换原来的三行表情代码

  servoFL.write(LEFT_BACK);
  servoBL.write(LEFT_BACK);
  servoFR.write(RIGHT_BACK);
  servoBR.write(RIGHT_BACK);
}

void turnLeft() {
  Serial.println("左转");
  uart1.println("左转");
  updateOLED(); // 替换原来的三行表情代码

  servoFL.write(LEFT_FORWARD);
  servoBL.write(LEFT_FORWARD);
  servoFR.write(STOP_SPEED);
  servoBR.write(STOP_SPEED);
}

void turnRight() {
  Serial.println("右转");
  uart1.println("右转");
  updateOLED(); // 替换原来的三行表情代码

  servoFL.write(STOP_SPEED);
  servoBL.write(STOP_SPEED);
  servoFR.write(RIGHT_FORWARD);
  servoBR.write(RIGHT_FORWARD);
}

void stopMovement() {
  Serial.println("停止");
  uart1.println("停止");
  updateOLED(); // 替换原来的三行表情代码

  servoFL.write(STOP_SPEED);
  servoFR.write(STOP_SPEED);
  servoBL.write(STOP_SPEED);
  servoBR.write(STOP_SPEED);
}

void sitDown() {
  Serial.println("坐下");
  uart1.println("坐下");
  updateOLED(); // 替换原来的三行表情代码

  stopMovement();
}

void lieDown() {
  Serial.println("趴下");
  uart1.println("趴下");
  updateOLED(); // 替换原来的三行表情代码

  stopMovement();
}

void dance() {
  Serial.println("跳舞");
  uart1.println("跳舞");
  updateOLED(); // 替换原来的三行表情代码

  for (int i = 0; i < 4; i++) {
    servoFL.write(LEFT_BACK);
    servoBL.write(LEFT_BACK);
    servoFR.write(RIGHT_FORWARD);
    servoBR.write(RIGHT_FORWARD);
    delay(500);
    servoFL.write(LEFT_FORWARD);
    servoBL.write(LEFT_FORWARD);
    servoFR.write(RIGHT_BACK);
    servoBR.write(RIGHT_BACK);
    delay(500);
  }
  stopMovement();
}

//================================== 指令处理 =========================================
void processCommand(char command) {
  if (command < 0 || command > 7) {
    return;
  }
  Serial.print("执行指令: ");
  Serial.println(command);
  uart1.print("执行指令: ");
  uart1.println(command);
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  switch (command) {
    case forwardCmd:
      
      moveForward();
      break;
    case backwardCmd:
      
      moveBackward();
      break;
    case leftCmd:
      
      turnLeft();
      break;
    case rightCmd:
      
      turnRight();
      break;
    case stopCmd:
      
      stopMovement();
      break;
    case sitDownCmd:
      
      sitDown();
      break;
    case lieDownCmd:
      
      lieDown();
      break;
    case danceCmd:
      
      dance();
      break;
    default:
      break;
  }
}

// ==================== 初始化 ====================
void setup() {
  Serial.begin(115200);
  Serial.println("四轮语音机器人控制程序启动");

  uart1.begin(uart1BaudRate, SERIAL_8N1, uart1RxPin, uart1TxPin);
  Serial.print("蓝牙串口就绪，波特率 ");
  Serial.println(uart1BaudRate);

  uart2.begin(uart2BaudRate, SERIAL_8N1, uart2RxPin, uart2TxPin);
  
  // 超声波引脚初始化
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  digitalWrite(TRIG_PIN, LOW);
  //OLED初始化
  Wire.begin(5, 6);
  // MPU6500初始化（与OLED共用I2C总线）
  if (!mpu6500Init()) {
    Serial.println("[警告] MPU6500初始化失败，转弯仅用时间控制");
  } 
  else {
    mpu6500CalibrateGyro();  // 新增：上电自动校准
    resetYaw();  // 上电自动归零航向角
  }
  //OLED初始化
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println(F("OLED初始化失败"));
    for (;;);
  }
  display.setRotation(2);
  delay(1000);

  servoFL.write(STOP_SPEED);
  servoFR.write(STOP_SPEED);
  servoBL.write(STOP_SPEED);
  servoBR.write(STOP_SPEED);
  servoFL.attach(servoPinFrontLeft);
  servoFR.attach(servoPinFrontRight);
  servoBL.attach(servoPinBackLeft);
  servoBR.attach(servoPinBackRight);
  
  connectWiFi();
  initMicrophone();
  randomSeed(analogRead(0));

  // 【新增】初始化按键
  initKey();
  

  Serial.println("初始化完成，AI语音就绪");
  BlueSerial_SendString("系统就绪\r\n");
  Serial.println("初始化完成，等待指令");
  // 开机显示默认模式
  updateOLED();

  WiFi.disconnect(false);
  delay(200);
  WiFi.reconnect();
}

void loop() {

  // 障碍物检测：全模式最高优先级
  checkObstacle();
  // MPU6500姿态更新（全模式运行，提供角度数据）
  updateAttitude();
  
  // 【新增】按键检测，最高优先级
  handleKeySwitch();
  
  // WebSocket保活（仅连接状态下执行）
  if(wsConnected){
    webSocket.loop();
    if(millis() - lastPingTime > WS_PING_INTERVAL){
      webSocket.sendTXT("ping");
      lastPingTime = millis();
    }
  }

  // 1. AI状态机：仅AI大模型模式下运行
  if (ctrlMode == MODE_LLM_ASR) {
    processAI();
  }
  
  // 2. 动作队列：仅AI大模型模式下运行
  if (ctrlMode == MODE_LLM_ASR) {
    processActionQueue();
  }
  
  // 3. 固定语音/UART2指令：固定语音模式 + AI模式均生效
  if (ctrlMode != MODE_BLUETOOTH && uart2.available()) {
    char cmd = uart2.read();
    Serial.print("[UART2] 收到字节: 0x");
    Serial.println(cmd, HEX);

    // 仅AI模式下响应唤醒信号，启动云端ASR
    if (ctrlMode == MODE_LLM_ASR && cmd == WAKEUP_SIGNAL && aiState == AI_IDLE) {
      Serial.println("[唤醒] 启动云端语音识别");
      showStatus("Connecting...");
      startStreamASR();
    } 
    // 固定指令：可打断当前动作
    else if (!isActionRunning) {
      if(aiState == AI_RECORDING || aiState == AI_WAIT_RESULT){
        if(wsConnected){
          webSocket.disconnect();
          wsConnected = false;
          for(int i=0;i<100;i++) webSocket.loop();
        }
      }
      clearActionQueue();
      processCommand(cmd);
      aiState = AI_IDLE;
      showStatus("Ready");
    }
  }

  // 4. 蓝牙控制：仅蓝牙模式下生效
  if (ctrlMode == MODE_BLUETOOTH) {
    while (uart1.available()) {
      BlueSerial_Put(uart1.read());
    }
    if (BlueSerial_ReceiveFlag()) {
      BlueSerial_Receive();
      clearActionQueue();
      aiState = AI_IDLE;
      
      if (strcasecmp(BlueSerial_StringArray[0], "joystick") == 0) {
        controlByJoystick(atoi(BlueSerial_StringArray[2]), atoi(BlueSerial_StringArray[3]));
      } 
      else if (strcasecmp(BlueSerial_StringArray[0], "key") == 0) {
        if (strcmp(BlueSerial_StringArray[2], "up") == 0) {
          processCommand(atoi(BlueSerial_StringArray[1]));
        }
      }
    }
  } 
  else {
    // 非蓝牙模式：清空蓝牙缓冲区，丢弃数据
    while (uart1.available()) uart1.read();
    BlueSerial_ClearBuffer();
  }
  
  delay(2);
}
